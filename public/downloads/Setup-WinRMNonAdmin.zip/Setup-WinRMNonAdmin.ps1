﻿<#
.SYNOPSIS
    Configures WinRM for non-administrator remote management access.

.DESCRIPTION
    This script automates the complete setup of Windows Remote Management (WinRM)
    to allow monitoring and management capabilities without requiring local
    administrator privileges. Designed for the OmniGaze WinRM Provider.

    The script performs:
    - Service account creation (optional)
    - Group membership configuration
    - WinRM service enablement and configuration
    - WinRM permission grants (SDDL)
    - WMI namespace permission grants
    - Firewall rule configuration
    - Verification tests

.PARAMETER ServiceAccount
    The service account to configure (e.g., "DOMAIN\svc-winrm-monitor" or "svc-winrm-monitor" for local).
    Required parameter.

.PARAMETER CreateLocalAccount
    If specified, creates a local service account with the name provided in ServiceAccount.
    Will prompt for password if -Password is not provided.

.PARAMETER Password
    Password for the local account when using -CreateLocalAccount.
    Should be a SecureString. If not provided, will prompt interactively.

.PARAMETER SkipWMIPermissions
    Skip WMI namespace permission configuration (useful if already configured via GPO).

.PARAMETER SkipFirewall
    Skip firewall rule configuration (useful if managed by GPO or external firewall).

.PARAMETER EnableHTTPS
    Also configure HTTPS listener (port 5986). Requires a valid certificate.

.PARAMETER CertificateThumbprint
    Certificate thumbprint for HTTPS listener. Required if -EnableHTTPS is specified.

.PARAMETER MaxMemoryPerShellMB
    Maximum memory per remote shell in MB. Default: 2048.

.PARAMETER TestOnly
    Only run verification tests without making any changes.

.PARAMETER Force
    Skip confirmation prompts.

.PARAMETER LogPath
    Path to save the setup log. Default: Script directory with timestamp.

.EXAMPLE
    .\Setup-WinRMNonAdmin.ps1 -ServiceAccount "DOMAIN\svc-winrm-monitor"

    Configures WinRM for the specified domain service account.

.EXAMPLE
    .\Setup-WinRMNonAdmin.ps1 -ServiceAccount "svc-omnigaze" -CreateLocalAccount

    Creates a local account and configures WinRM for it.

.EXAMPLE
    .\Setup-WinRMNonAdmin.ps1 -ServiceAccount "DOMAIN\svc-winrm-monitor" -TestOnly

    Only runs verification tests for the specified account.

.EXAMPLE
    .\Setup-WinRMNonAdmin.ps1 -ServiceAccount "DOMAIN\svc-winrm-monitor" -EnableHTTPS -CertificateThumbprint "ABC123..."

    Configures WinRM with both HTTP and HTTPS listeners.

.NOTES
    Version:        1.0
    Author:         OmniGaze
    Creation Date:  2025-01-21
    Purpose:        Automate WinRM non-admin configuration for OmniGaze monitoring

    IMPORTANT: Must be run with Administrator privileges.

    Reference: WinRM-NonAdmin-Setup-Guide.md

.LINK
    https://docs.microsoft.com/en-us/windows/win32/winrm/installation-and-configuration-for-windows-remote-management
#>

#Requires -Version 5.1
#Requires -RunAsAdministrator

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $true, Position = 0, HelpMessage = "Service account to configure (e.g., DOMAIN\svc-winrm-monitor)")]
    [ValidateNotNullOrEmpty()]
    [string]$ServiceAccount,

    [Parameter(HelpMessage = "Create a local service account")]
    [switch]$CreateLocalAccount,

    [Parameter(HelpMessage = "Password for local account creation")]
    [SecureString]$Password,

    [Parameter(HelpMessage = "Skip WMI namespace permissions (CIM queries won't work without them)")]
    [switch]$SkipWMINamespacePermissions,

    [Parameter(HelpMessage = "Skip firewall rule configuration")]
    [switch]$SkipFirewall,

    [Parameter(HelpMessage = "Enable HTTPS listener (port 5986)")]
    [switch]$EnableHTTPS,

    [Parameter(HelpMessage = "Certificate thumbprint for HTTPS")]
    [string]$CertificateThumbprint,

    [Parameter(HelpMessage = "Max memory per shell in MB")]
    [ValidateRange(512, 8192)]
    [int]$MaxMemoryPerShellMB = 2048,

    [Parameter(HelpMessage = "Only run verification tests")]
    [switch]$TestOnly,

    [Parameter(HelpMessage = "Skip confirmation prompts")]
    [switch]$Force,

    [Parameter(HelpMessage = "Path for log file")]
    [string]$LogPath
)

#region Script Configuration
$ErrorActionPreference = 'Stop'
$Script:StartTime = Get-Date
$Script:LogMessages = [System.Collections.ArrayList]::new()
$Script:Errors = [System.Collections.ArrayList]::new()
$Script:Warnings = [System.Collections.ArrayList]::new()

# Required group memberships for WinRM READ-ONLY access
# NOTE: "Distributed COM Users" is intentionally EXCLUDED to block direct WMI (DCOM/RPC)
# NOTE: "Remote Desktop Users" is excluded as not needed for monitoring
$Script:RequiredGroups = @(
    "Remote Management Users",      # Required for WinRM/PowerShell remoting
    "Performance Monitor Users",    # Required for performance counter access
    "Event Log Readers"             # Required for event log access
)

# WMI permissions to grant (Enable Account = 1, Remote Enable = 32)
$Script:WMIPermissionMask = 33  # 0x21 = Enable Account + Remote Enable
#endregion

#region Logging Functions
function Write-Log {
    param(
        [Parameter(Mandatory)]
        [string]$Message,

        [ValidateSet('Info', 'Success', 'Warning', 'Error', 'Debug')]
        [string]$Level = 'Info'
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"

    [void]$Script:LogMessages.Add($logEntry)

    switch ($Level) {
        'Info'    { Write-Host $Message -ForegroundColor Cyan }
        'Success' { Write-Host $Message -ForegroundColor Green }
        'Warning' {
            Write-Host $Message -ForegroundColor Yellow
            [void]$Script:Warnings.Add($Message)
        }
        'Error'   {
            Write-Host $Message -ForegroundColor Red
            [void]$Script:Errors.Add($Message)
        }
        'Debug'   { Write-Verbose $Message }
    }
}

function Write-Section {
    param([string]$Title)

    $separator = "=" * 60
    Write-Host ""
    Write-Host $separator -ForegroundColor White
    Write-Host " $Title" -ForegroundColor White
    Write-Host $separator -ForegroundColor White
    Write-Log -Message "=== $Title ===" -Level Debug
}

function Save-Log {
    param([string]$Path)

    if (-not $Path) {
        $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
        if (-not $scriptDir) { $scriptDir = $PWD }
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $Path = Join-Path $scriptDir "WinRM-Setup-Log_$timestamp.txt"
    }

    try {
        $Script:LogMessages | Out-File -FilePath $Path -Encoding UTF8
        Write-Host "Log saved to: $Path" -ForegroundColor Gray
        return $Path
    }
    catch {
        Write-Warning "Failed to save log: $_"
        return $null
    }
}
#endregion

#region Helper Functions
function Test-IsDomainAccount {
    param([string]$Account)
    return $Account -match '\\'
}

function Get-AccountSID {
    param([string]$Account)

    try {
        $ntAccount = New-Object System.Security.Principal.NTAccount($Account)
        $sid = $ntAccount.Translate([System.Security.Principal.SecurityIdentifier])
        return $sid.Value
    }
    catch {
        Write-Log "Failed to resolve SID for $Account : $_" -Level Warning
        return $null
    }
}

function Test-AccountExists {
    param([string]$Account)

    try {
        $null = Get-AccountSID -Account $Account
        return $true
    }
    catch {
        return $false
    }
}

function Test-LocalGroupExists {
    param([string]$GroupName)

    try {
        $null = Get-LocalGroup -Name $GroupName -ErrorAction Stop
        return $true
    }
    catch {
        return $false
    }
}

function Test-IsGroupMember {
    param(
        [string]$GroupName,
        [string]$Account
    )

    try {
        $members = Get-LocalGroupMember -Group $GroupName -ErrorAction SilentlyContinue
        foreach ($member in $members) {
            if ($member.Name -eq $Account -or
                $member.Name -like "*\$($Account.Split('\')[-1])") {
                return $true
            }
        }
        return $false
    }
    catch {
        return $false
    }
}

function Test-ShouldProcess {
    param(
        [string]$Target,
        [string]$Action
    )
    # When running remotely via Invoke-Command, $PSCmdlet is not available
    # In that case, honor the -Force flag or return true
    if ($null -eq $PSCmdlet) {
        return $true
    }
    try {
        return $PSCmdlet.ShouldProcess($Target, $Action)
    }
    catch {
        # If ShouldProcess fails (e.g., in remote session), return true when Force is set
        return $Force -or $true
    }
}
#endregion

#region Configuration Functions
function New-LocalServiceAccount {
    param(
        [string]$AccountName,
        [SecureString]$AccountPassword
    )

    Write-Log "Creating local service account: $AccountName"

    # Check if account already exists
    try {
        $existing = Get-LocalUser -Name $AccountName -ErrorAction SilentlyContinue
        if ($existing) {
            Write-Log "Local account '$AccountName' already exists" -Level Warning
            return $true
        }
    }
    catch { }

    # Prompt for password if not provided
    if (-not $AccountPassword) {
        Write-Host "Enter password for local account '$AccountName':" -ForegroundColor Yellow
        $AccountPassword = Read-Host -AsSecureString
        Write-Host "Confirm password:" -ForegroundColor Yellow
        $confirmPassword = Read-Host -AsSecureString

        # Verify passwords match
        $bstr1 = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($AccountPassword)
        $bstr2 = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($confirmPassword)
        try {
            $plain1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr1)
            $plain2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr2)
            if ($plain1 -ne $plain2) {
                throw "Passwords do not match"
            }
        }
        finally {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr1)
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr2)
        }
    }

    try {
        $params = @{
            Name                     = $AccountName
            Password                 = $AccountPassword
            PasswordNeverExpires     = $true
            UserMayNotChangePassword = $true
            AccountNeverExpires      = $true
            Description              = "OmniGaze WinRM Monitoring Service Account"
        }

        New-LocalUser @params | Out-Null
        Write-Log "Local account '$AccountName' created successfully" -Level Success
        return $true
    }
    catch {
        Write-Log "Failed to create local account: $_" -Level Error
        return $false
    }
}

function Add-AccountToGroups {
    param([string]$Account)

    Write-Log "Configuring group memberships for: $Account"

    $results = @{
        Success = @()
        Failed  = @()
        Skipped = @()
    }

    foreach ($groupName in $Script:RequiredGroups) {
        # Check if group exists
        if (-not (Test-LocalGroupExists -GroupName $groupName)) {
            Write-Log "Group '$groupName' does not exist on this system - skipping" -Level Warning
            $results.Skipped += $groupName
            continue
        }

        # Check if already a member
        if (Test-IsGroupMember -GroupName $groupName -Account $Account) {
            Write-Log "  Already member of: $groupName" -Level Debug
            $results.Skipped += $groupName
            continue
        }

        # Add to group
        try {
            if (Test-ShouldProcess -Target $groupName -Action "Add $Account to group") {
                Add-LocalGroupMember -Group $groupName -Member $Account -ErrorAction Stop
                Write-Log "  Added to: $groupName" -Level Success
                $results.Success += $groupName
            }
        }
        catch {
            Write-Log "  Failed to add to $groupName : $_" -Level Error
            $results.Failed += $groupName
        }
    }

    return $results
}

function Enable-WinRMService {
    Write-Log "Configuring WinRM service..."

    try {
        # Check current WinRM status
        $winrmService = Get-Service -Name WinRM -ErrorAction SilentlyContinue

        if (-not $winrmService) {
            throw "WinRM service not found on this system"
        }

        # Enable PS Remoting (this also runs winrm quickconfig)
        if (Test-ShouldProcess -Target "WinRM" -Action "Enable PS Remoting") {
            Write-Log "  Running Enable-PSRemoting..."
            Enable-PSRemoting -Force -SkipNetworkProfileCheck | Out-Null
            Write-Log "  PS Remoting enabled" -Level Success
        }

        # Ensure service is set to automatic
        if (Test-ShouldProcess -Target "WinRM Service" -Action "Set startup type to Automatic") {
            Set-Service -Name WinRM -StartupType Automatic
            Write-Log "  Service startup set to Automatic" -Level Success
        }

        # Start service if not running
        $winrmService = Get-Service -Name WinRM
        if ($winrmService.Status -ne 'Running') {
            if (Test-ShouldProcess -Target "WinRM Service" -Action "Start service") {
                Start-Service -Name WinRM
                Write-Log "  Service started" -Level Success
            }
        }

        # Configure memory limits
        if (Test-ShouldProcess -Target "WinRM" -Action "Set MaxMemoryPerShellMB to $MaxMemoryPerShellMB") {
            Set-Item WSMan:\localhost\Shell\MaxMemoryPerShellMB $MaxMemoryPerShellMB -Force
            Write-Log "  MaxMemoryPerShellMB set to $MaxMemoryPerShellMB" -Level Success
        }

        return $true
    }
    catch {
        Write-Log "Failed to configure WinRM service: $_" -Level Error
        return $false
    }
}

function Set-WinRMPermissions {
    param([string]$Account)

    Write-Log "Configuring WinRM permissions for: $Account"

    try {
        $sid = Get-AccountSID -Account $Account
        if (-not $sid) {
            throw "Could not resolve SID for account: $Account"
        }

        # Get current SDDL
        $currentSDDL = (Get-Item WSMan:\localhost\Service\RootSDDL).Value
        Write-Log "  Current RootSDDL retrieved" -Level Debug

        # Check if account already has permissions
        if ($currentSDDL -match $sid) {
            Write-Log "  Account already has WinRM permissions" -Level Warning
            return $true
        }

        # Build new ACE for the account
        # A = Allow, GA = Generic All, but we want more limited: GR (Generic Read) + GX (Generic Execute)
        # For WinRM: We need Invoke (0x1) + Read (0x2) = 0x3
        # SDDL rights: RC = Read Control, WD = Write DAC, but for WinRM we use specific rights
        # Standard WinRM permission ACE: (A;;GA;;;SID) for full, (A;;GR;;;SID) for read
        # For non-admin, we grant: Generic Read + Generic Execute
        $newACE = "(A;;GXGR;;;$sid)"

        # Insert new ACE before the S: (SACL) section if it exists
        # SDDL format: O:owner G:group D:dacl_flags(ace1)(ace2)...S:sacl_flags(ace)...
        if ($currentSDDL -match "S:") {
            # Insert ACE before SACL section
            $newSDDL = $currentSDDL -replace "S:", "${newACE}S:"
        }
        else {
            # No SACL, just append ACE
            $newSDDL = $currentSDDL + $newACE
        }

        if (Test-ShouldProcess -Target "WinRM RootSDDL" -Action "Add permissions for $Account") {
            Set-Item WSMan:\localhost\Service\RootSDDL -Value $newSDDL -Force
            Write-Log "  WinRM permissions granted" -Level Success
        }

        # Also configure PowerShell session configuration
        Write-Log "  Configuring PowerShell session permissions..."

        $psSessionSDDL = (Get-PSSessionConfiguration -Name Microsoft.PowerShell).SecurityDescriptorSddl
        if ($psSessionSDDL -and -not ($psSessionSDDL -match $sid)) {
            # Insert ACE before S: (SACL) section if it exists
            if ($psSessionSDDL -match "S:") {
                $newPSSDDL = $psSessionSDDL -replace "S:", "${newACE}S:"
            }
            else {
                $newPSSDDL = $psSessionSDDL + $newACE
            }

            if (Test-ShouldProcess -Target "Microsoft.PowerShell session" -Action "Add permissions for $Account") {
                Set-PSSessionConfiguration -Name Microsoft.PowerShell -SecurityDescriptorSddl $newPSSDDL -Force -NoServiceRestart
                Write-Log "  PowerShell session permissions granted" -Level Success
            }
        }
        else {
            Write-Log "  PowerShell session permissions already configured" -Level Debug
        }

        return $true
    }
    catch {
        Write-Log "Failed to configure WinRM permissions: $_" -Level Error
        return $false
    }
}

function Set-WMINamespacePermissions {
    param(
        [string]$Account,
        [string]$Namespace = "root\cimv2"
    )

    Write-Log "Configuring WMI namespace permissions for: $Account on $Namespace"

    try {
        $sid = Get-AccountSID -Account $Account
        if (-not $sid) {
            throw "Could not resolve SID for account: $Account"
        }

        # Get the namespace security
        $security = Get-WmiObject -Namespace $Namespace -Class __SystemSecurity

        # Get current security descriptor using PSBase.InvokeMethod (works in all contexts)
        $outParams = $security.PSBase.InvokeMethod("GetSD", $null, $null)

        if ($outParams.ReturnValue -ne 0) {
            throw "Failed to get security descriptor. Return code: $($outParams.ReturnValue)"
        }

        # Convert binary SD to manageable object
        $converter = New-Object System.Management.ManagementClass("Win32_SecurityDescriptorHelper")
        $sdResult = $converter.BinarySDToWin32SD($outParams.SD)
        $sd = $sdResult.Descriptor

        # Check if ACE already exists for this SID
        $existingAce = $sd.DACL | Where-Object {
            $_.Trustee.SIDString -eq $sid
        }

        if ($existingAce) {
            Write-Log "  Account already has WMI permissions on $Namespace" -Level Warning
            return $true
        }

        # Create new ACE
        # Permissions: Enable Account (0x1), Execute Methods (0x2), Full Write (0x4),
        #              Partial Write (0x8), Provider Write (0x10), Remote Enable (0x20), Read Security (0x20000)
        # For non-admin monitoring: Enable (1) + Remote Enable (32) + Read Security (131072) = 131105
        $permissionMask = 131105  # 0x20021

        # Create trustee
        $trustee = ([WMIClass]"Win32_Trustee").CreateInstance()
        $trustee.SIDString = $sid

        # Create ACE
        $ace = ([WMIClass]"Win32_ACE").CreateInstance()
        $ace.AccessMask = $permissionMask
        $ace.AceFlags = 2  # CONTAINER_INHERIT_ACE - inherit to child namespaces
        $ace.AceType = 0   # Access Allowed
        $ace.Trustee = $trustee

        # Add ACE to DACL
        $newDACL = $sd.DACL + @($ace)
        $sd.DACL = $newDACL

        # Convert back to binary and set using PSBase.InvokeMethod
        $binaryResult = $converter.Win32SDToBinarySD($sd)

        if (Test-ShouldProcess -Target "WMI Namespace $Namespace" -Action "Add permissions for $Account") {
            $inParams = $security.PSBase.GetMethodParameters("SetSD")
            $inParams["SD"] = $binaryResult.BinarySD
            $setResult = $security.PSBase.InvokeMethod("SetSD", $inParams, $null)

            if ($setResult.ReturnValue -ne 0) {
                throw "Failed to set security descriptor. Return code: $($setResult.ReturnValue)"
            }

            Write-Log "  WMI permissions granted on $Namespace" -Level Success
        }

        return $true
    }
    catch {
        Write-Log "Failed to configure WMI permissions: $_" -Level Error
        Write-Log "  You may need to configure WMI permissions manually via wmimgmt.msc" -Level Warning
        return $false
    }
}

function Enable-FirewallRules {
    Write-Log "Configuring firewall rules..."

    try {
        # Check for existing WinRM rules
        $existingRules = Get-NetFirewallRule -DisplayName "*Windows Remote Management*" -ErrorAction SilentlyContinue

        if ($existingRules) {
            # Enable existing rules
            foreach ($rule in $existingRules) {
                if (-not $rule.Enabled) {
                    if (Test-ShouldProcess -Target $rule.DisplayName -Action "Enable firewall rule") {
                        Enable-NetFirewallRule -Name $rule.Name
                        Write-Log "  Enabled: $($rule.DisplayName)" -Level Success
                    }
                }
                else {
                    Write-Log "  Already enabled: $($rule.DisplayName)" -Level Debug
                }
            }
        }
        else {
            # Create new rule for HTTP
            if (Test-ShouldProcess -Target "WinRM HTTP (5985)" -Action "Create firewall rule") {
                New-NetFirewallRule -DisplayName "WinRM HTTP (OmniGaze)" `
                    -Direction Inbound `
                    -Protocol TCP `
                    -LocalPort 5985 `
                    -Action Allow `
                    -Profile Domain, Private `
                    -Description "Allow WinRM HTTP for OmniGaze monitoring" `
                    -Program "System" | Out-Null
                Write-Log "  Created HTTP rule (port 5985)" -Level Success
            }
        }

        # Create HTTPS rule if requested
        if ($EnableHTTPS) {
            $httpsRule = Get-NetFirewallRule -DisplayName "*WinRM*HTTPS*" -ErrorAction SilentlyContinue

            if (-not $httpsRule) {
                if (Test-ShouldProcess -Target "WinRM HTTPS (5986)" -Action "Create firewall rule") {
                    New-NetFirewallRule -DisplayName "WinRM HTTPS (OmniGaze)" `
                        -Direction Inbound `
                        -Protocol TCP `
                        -LocalPort 5986 `
                        -Action Allow `
                        -Profile Domain, Private `
                        -Description "Allow WinRM HTTPS for OmniGaze monitoring" `
                        -Program "System" | Out-Null
                    Write-Log "  Created HTTPS rule (port 5986)" -Level Success
                }
            }
        }

        return $true
    }
    catch {
        Write-Log "Failed to configure firewall rules: $_" -Level Error
        return $false
    }
}

function Enable-HTTPSListener {
    param([string]$Thumbprint)

    Write-Log "Configuring HTTPS listener..."

    try {
        # Verify certificate exists
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $Thumbprint }

        if (-not $cert) {
            throw "Certificate with thumbprint '$Thumbprint' not found in LocalMachine\My store"
        }

        Write-Log "  Found certificate: $($cert.Subject)" -Level Debug

        # Check for existing HTTPS listener
        $existingListener = Get-ChildItem WSMan:\localhost\Listener | Where-Object { $_.Keys -contains "Transport=HTTPS" }

        if ($existingListener) {
            Write-Log "  HTTPS listener already exists" -Level Warning
            return $true
        }

        # Create HTTPS listener
        if (Test-ShouldProcess -Target "WinRM HTTPS Listener" -Action "Create with certificate $Thumbprint") {
            New-Item -Path WSMan:\localhost\Listener `
                -Transport HTTPS `
                -Address * `
                -CertificateThumbprint $Thumbprint `
                -Force | Out-Null
            Write-Log "  HTTPS listener created" -Level Success
        }

        return $true
    }
    catch {
        Write-Log "Failed to configure HTTPS listener: $_" -Level Error
        return $false
    }
}

function Set-LocalAccountTokenFilterPolicy {
    param([bool]$Enable = $true)

    Write-Log "Configuring LocalAccountTokenFilterPolicy..."

    $regPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    $regName = "LocalAccountTokenFilterPolicy"

    try {
        $currentValue = Get-ItemProperty -Path $regPath -Name $regName -ErrorAction SilentlyContinue

        if ($Enable) {
            if ($currentValue.$regName -eq 1) {
                Write-Log "  LocalAccountTokenFilterPolicy already enabled" -Level Debug
                return $true
            }

            if (Test-ShouldProcess -Target "LocalAccountTokenFilterPolicy" -Action "Set to 1") {
                Set-ItemProperty -Path $regPath -Name $regName -Value 1 -Type DWord -Force
                Write-Log "  LocalAccountTokenFilterPolicy enabled" -Level Success
                Write-Log "  WARNING: This reduces security for local accounts" -Level Warning
            }
        }

        return $true
    }
    catch {
        Write-Log "Failed to configure LocalAccountTokenFilterPolicy: $_" -Level Error
        return $false
    }
}
#endregion

#region Verification Functions
function Test-WinRMConfiguration {
    param([string]$Account)

    Write-Section "Verification Tests"

    $results = [ordered]@{
        "WinRM Service Running"     = $false
        "WinRM Listener Active"     = $false
        "Group Memberships"         = $false
        "WinRM Permissions"         = $false
        "Firewall Rules"            = $false
        "Port 5985 Accessible"      = $false
    }

    # Test 1: WinRM Service
    Write-Log "Testing WinRM service..."
    try {
        $service = Get-Service -Name WinRM
        if ($service.Status -eq 'Running') {
            $results["WinRM Service Running"] = $true
            Write-Log "  WinRM service is running" -Level Success
        }
        else {
            Write-Log "  WinRM service status: $($service.Status)" -Level Error
        }
    }
    catch {
        Write-Log "  Failed to check WinRM service: $_" -Level Error
    }

    # Test 2: WinRM Listener
    Write-Log "Testing WinRM listeners..."
    try {
        $listeners = Get-ChildItem WSMan:\localhost\Listener -ErrorAction Stop
        if ($listeners) {
            $results["WinRM Listener Active"] = $true
            foreach ($listener in $listeners) {
                $transport = ($listener | Get-ChildItem | Where-Object { $_.Name -eq "Transport" }).Value
                $port = ($listener | Get-ChildItem | Where-Object { $_.Name -eq "Port" }).Value
                Write-Log "  Listener: $transport on port $port" -Level Success
            }
        }
        else {
            Write-Log "  No WinRM listeners found" -Level Error
        }
    }
    catch {
        Write-Log "  Failed to enumerate listeners: $_" -Level Error
    }

    # Test 3: Group Memberships
    Write-Log "Testing group memberships for: $Account"
    $groupsOK = $true
    foreach ($groupName in $Script:RequiredGroups) {
        if (Test-LocalGroupExists -GroupName $groupName) {
            if (Test-IsGroupMember -GroupName $groupName -Account $Account) {
                Write-Log "  Member of: $groupName" -Level Success
            }
            else {
                Write-Log "  NOT member of: $groupName" -Level Error
                $groupsOK = $false
            }
        }
    }
    $results["Group Memberships"] = $groupsOK

    # Test 4: WinRM Permissions
    Write-Log "Testing WinRM permissions..."
    try {
        $sid = Get-AccountSID -Account $Account
        if ($sid) {
            $rootSDDL = (Get-Item WSMan:\localhost\Service\RootSDDL).Value
            if ($rootSDDL -match $sid) {
                $results["WinRM Permissions"] = $true
                Write-Log "  WinRM permissions configured" -Level Success
            }
            else {
                Write-Log "  WinRM permissions not found for account" -Level Error
            }
        }
    }
    catch {
        Write-Log "  Failed to check WinRM permissions: $_" -Level Error
    }

    # Test 5: Firewall Rules
    Write-Log "Testing firewall rules..."
    try {
        $winrmRules = Get-NetFirewallRule -DisplayName "*WinRM*", "*Windows Remote Management*" -ErrorAction SilentlyContinue |
            Where-Object { $_.Enabled -eq $true -and $_.Direction -eq 'Inbound' }

        if ($winrmRules) {
            $results["Firewall Rules"] = $true
            Write-Log "  Firewall rules enabled: $($winrmRules.Count) rule(s)" -Level Success
        }
        else {
            Write-Log "  No enabled WinRM firewall rules found" -Level Error
        }
    }
    catch {
        Write-Log "  Failed to check firewall rules: $_" -Level Error
    }

    # Test 6: Port Accessibility
    Write-Log "Testing port accessibility..."
    try {
        $tcpTest = Test-NetConnection -ComputerName localhost -Port 5985 -WarningAction SilentlyContinue
        if ($tcpTest.TcpTestSucceeded) {
            $results["Port 5985 Accessible"] = $true
            Write-Log "  Port 5985 is accessible" -Level Success
        }
        else {
            Write-Log "  Port 5985 is not accessible" -Level Error
        }
    }
    catch {
        Write-Log "  Failed to test port: $_" -Level Error
    }

    # Summary
    Write-Host ""
    Write-Host "Test Results Summary:" -ForegroundColor White
    Write-Host "-" * 40

    $passCount = 0
    foreach ($test in $results.Keys) {
        $status = if ($results[$test]) { "[PASS]"; $passCount++ } else { "[FAIL]" }
        $color = if ($results[$test]) { "Green" } else { "Red" }
        Write-Host "  $status $test" -ForegroundColor $color
    }

    Write-Host "-" * 40
    Write-Host "  Passed: $passCount / $($results.Count)" -ForegroundColor $(if ($passCount -eq $results.Count) { "Green" } else { "Yellow" })

    return $results
}

function Test-RemoteConnection {
    param(
        [string]$Account,
        [PSCredential]$Credential
    )

    Write-Log "Testing remote connection capability..."

    if (-not $Credential) {
        Write-Host "Enter credentials for $Account to test remote connection:" -ForegroundColor Yellow
        $Credential = Get-Credential -UserName $Account -Message "Enter password to test WinRM connection"
    }

    if (-not $Credential) {
        Write-Log "  Skipping remote test - no credentials provided" -Level Warning
        return $false
    }

    try {
        # Test WSMan
        $wsmanTest = Test-WSMan -ComputerName localhost -Credential $Credential -Authentication Negotiate -ErrorAction Stop
        Write-Log "  WSMan test successful" -Level Success

        # Test actual remote session
        $session = New-PSSession -ComputerName localhost -Credential $Credential -ErrorAction Stop

        # Test WMI query
        $osInfo = Invoke-Command -Session $session -ScriptBlock {
            Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version
        }

        Remove-PSSession -Session $session

        Write-Log "  Remote session test successful" -Level Success
        Write-Log "  Retrieved OS: $($osInfo.Caption)" -Level Success

        return $true
    }
    catch {
        Write-Log "  Remote connection test failed: $_" -Level Error
        return $false
    }
}
#endregion

#region Main Execution
function Invoke-Main {
    # Display banner
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "     OmniGaze WinRM Non-Admin Configuration Script              " -ForegroundColor Cyan
    Write-Host "                        Version 1.0                             " -ForegroundColor Cyan
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""

    Write-Log "Script started at: $Script:StartTime" -Level Debug
    Write-Log "Target account: $ServiceAccount" -Level Info
    Write-Log "Computer name: $env:COMPUTERNAME" -Level Debug

    # Validate parameters
    if ($EnableHTTPS -and -not $CertificateThumbprint) {
        Write-Log "ERROR: -CertificateThumbprint is required when using -EnableHTTPS" -Level Error
        return
    }

    # Determine if domain or local account
    $isDomainAccount = Test-IsDomainAccount -Account $ServiceAccount
    Write-Log "Account type: $(if ($isDomainAccount) { 'Domain' } else { 'Local' })" -Level Info

    # Test-only mode
    if ($TestOnly) {
        Write-Log "Running in TEST-ONLY mode - no changes will be made" -Level Warning
        $testResults = Test-WinRMConfiguration -Account $ServiceAccount

        # Offer to test actual connection
        Write-Host ""
        $testConnection = Read-Host "Would you like to test the actual remote connection? (Y/N)"
        if ($testConnection -eq 'Y') {
            Test-RemoteConnection -Account $ServiceAccount
        }

        Save-Log -Path $LogPath
        return
    }

    # Confirmation prompt
    if (-not $Force) {
        Write-Host ""
        Write-Host "This script will configure WinRM for non-admin access on this system." -ForegroundColor Yellow
        Write-Host "The following changes will be made:" -ForegroundColor Yellow
        Write-Host "  - Add '$ServiceAccount' to required local groups (WinRM only, NO DCOM)" -ForegroundColor White
        Write-Host "  - Enable and configure WinRM service" -ForegroundColor White
        Write-Host "  - Grant WinRM permissions to the service account" -ForegroundColor White
        if (-not $SkipWMINamespacePermissions) {
            Write-Host "  - Grant WMI namespace permissions (for CIM queries via WinRM)" -ForegroundColor White
        }
        Write-Host "  - Direct WMI (DCOM/RPC port 135) will be BLOCKED" -ForegroundColor Green
        if (-not $SkipFirewall) {
            Write-Host "  - Configure firewall rules" -ForegroundColor White
        }
        if (-not $isDomainAccount) {
            Write-Host "  - Enable LocalAccountTokenFilterPolicy (for local account)" -ForegroundColor White
        }
        Write-Host ""

        $confirm = Read-Host "Continue? (Y/N)"
        if ($confirm -ne 'Y') {
            Write-Log "Operation cancelled by user" -Level Warning
            return
        }
    }

    # Step 1: Create local account if requested
    if ($CreateLocalAccount) {
        Write-Section "Step 1: Create Local Account"

        $accountName = $ServiceAccount.Split('\')[-1]  # Remove domain prefix if present
        if (-not (New-LocalServiceAccount -AccountName $accountName -AccountPassword $Password)) {
            Write-Log "Failed to create local account. Aborting." -Level Error
            Save-Log -Path $LogPath
            return
        }
        $ServiceAccount = $accountName  # Update to local account name
    }
    else {
        Write-Section "Step 1: Verify Account"

        if (-not (Test-AccountExists -Account $ServiceAccount)) {
            Write-Log "Account '$ServiceAccount' does not exist or cannot be resolved" -Level Error
            Write-Log "Ensure the account exists and is accessible from this machine" -Level Error
            Save-Log -Path $LogPath
            return
        }
        Write-Log "Account verified: $ServiceAccount" -Level Success
    }

    # Step 2: Add to groups
    Write-Section "Step 2: Configure Group Memberships"
    $groupResults = Add-AccountToGroups -Account $ServiceAccount

    if ($groupResults.Failed.Count -gt 0) {
        Write-Log "Some group memberships failed. Manual configuration may be required." -Level Warning
    }

    # Step 3: Enable WinRM
    Write-Section "Step 3: Configure WinRM Service"
    if (-not (Enable-WinRMService)) {
        Write-Log "WinRM service configuration failed" -Level Error
    }

    # Step 4: Configure WinRM permissions
    Write-Section "Step 4: Configure WinRM Permissions"
    if (-not (Set-WinRMPermissions -Account $ServiceAccount)) {
        Write-Log "WinRM permission configuration failed" -Level Warning
    }

    # Step 5: Configure WMI namespace permissions (required for CIM queries via WinRM)
    # NOTE: Direct WMI (DCOM/RPC port 135) is BLOCKED by not adding to "Distributed COM Users"
    # WMI namespace permissions only allow CIM queries over WinRM, not direct WMI access
    if (-not $SkipWMINamespacePermissions) {
        Write-Section "Step 5: Configure WMI Namespace Permissions"
        Write-Log "Granting WMI namespace permissions for CIM queries via WinRM" -Level Info
        Write-Log "NOTE: Direct WMI (DCOM) is still blocked - only CIM over WinRM works" -Level Info
        if (-not (Set-WMINamespacePermissions -Account $ServiceAccount -Namespace "root\cimv2")) {
            Write-Log "WMI cimv2 permission configuration failed" -Level Warning
            Write-Log "Consider configuring WMI permissions manually via wmimgmt.msc" -Level Info
        }
        # Also configure standardcimv2 for network-related queries
        if (-not (Set-WMINamespacePermissions -Account $ServiceAccount -Namespace "root\standardcimv2")) {
            Write-Log "WMI standardcimv2 permission configuration failed (may not exist on all systems)" -Level Warning
        }
    }
    else {
        Write-Log "Skipping WMI namespace permissions (as requested)" -Level Warning
        Write-Log "WARNING: CIM queries (Get-CimInstance) will NOT work without WMI namespace permissions!" -Level Warning
    }

    # Step 6: Configure firewall
    if (-not $SkipFirewall) {
        Write-Section "Step 6: Configure Firewall Rules"
        if (-not (Enable-FirewallRules)) {
            Write-Log "Firewall configuration failed" -Level Warning
        }
    }
    else {
        Write-Log "Skipping firewall configuration (as requested)" -Level Info
    }

    # Step 7: HTTPS listener (optional)
    if ($EnableHTTPS) {
        Write-Section "Step 7: Configure HTTPS Listener"
        if (-not (Enable-HTTPSListener -Thumbprint $CertificateThumbprint)) {
            Write-Log "HTTPS listener configuration failed" -Level Warning
        }
    }

    # Step 8: LocalAccountTokenFilterPolicy for local accounts
    if (-not $isDomainAccount) {
        Write-Section "Step 8: Configure Local Account Policy"
        if (-not (Set-LocalAccountTokenFilterPolicy -Enable $true)) {
            Write-Log "LocalAccountTokenFilterPolicy configuration failed" -Level Warning
        }
    }

    # Final verification
    Write-Host ""
    $testResults = Test-WinRMConfiguration -Account $ServiceAccount

    # Summary
    Write-Section "Configuration Complete"

    $endTime = Get-Date
    $duration = $endTime - $Script:StartTime

    Write-Host ""
    Write-Host "Configuration completed in $($duration.TotalSeconds.ToString('F1')) seconds" -ForegroundColor Cyan
    Write-Host ""

    if ($Script:Errors.Count -gt 0) {
        Write-Host "Errors encountered: $($Script:Errors.Count)" -ForegroundColor Red
        foreach ($err in $Script:Errors) {
            Write-Host "  - $err" -ForegroundColor Red
        }
    }

    if ($Script:Warnings.Count -gt 0) {
        Write-Host "Warnings: $($Script:Warnings.Count)" -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor White
    Write-Host "  1. Test remote connection from your management system:" -ForegroundColor Gray
    Write-Host "     Test-WSMan -ComputerName $env:COMPUTERNAME -Credential $ServiceAccount" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  2. Configure OmniGaze WinRM Provider with:" -ForegroundColor Gray
    Write-Host "     - Hostname: $env:COMPUTERNAME" -ForegroundColor DarkGray
    Write-Host "     - Username: $ServiceAccount" -ForegroundColor DarkGray
    Write-Host "     - Port: $(if ($EnableHTTPS) { '5986 (HTTPS)' } else { '5985 (HTTP)' })" -ForegroundColor DarkGray
    Write-Host ""

    # Save log
    $logFile = Save-Log -Path $LogPath

    # Offer to test actual connection
    Write-Host ""
    $testConnection = Read-Host "Would you like to test the actual remote connection now? (Y/N)"
    if ($testConnection -eq 'Y') {
        Test-RemoteConnection -Account $ServiceAccount
    }
}

# Execute main function
try {
    Invoke-Main
}
catch {
    Write-Log "Unhandled error: $_" -Level Error
    Write-Log $_.ScriptStackTrace -Level Debug
    Save-Log -Path $LogPath
    throw
}
#endregion
